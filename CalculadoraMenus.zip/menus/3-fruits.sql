'PILAR-F1','piña en cazuela','1','Taza','100g',238,55.99,1.22,1.04
'PILAR-F2','Ensalada de frutas','1','Taza','100gr',192,40.28,3.7,1.76
'PILAR-F3','Ensalada de piña','1','Taza','100g',347,26.4,14.94,20.16
'PILAR-F4','Yogurth helado de fresa','1','Taza','100g',126,25.84,2.23,1.47
'PILAR-F5','Rosca de manzana y fresa','1','Rebanada','100g',1117,110.44,17.1,67.39
'PILAR-F6','Ensalada de jicama','1','Taza','100g',126,20.5,4.21,3.01
'PILAR-F7','Guayabas en almibar','1','Taza','100g',122,27.98,1.27,0.62
'PILAR-F8','Ensalada de manzana','1','Taza','100g',415,46.66,12.35,19.9
'PILAR-F9','Gajos de toronja','1','Taza','100g',50,12.6,0.8,0.2
'PILAR-F10','Guayaba','1','Pieza','135g',63,14.8,1,0.7
'PILAR-F11','Guayaba rosa','1','Taza','90g',52,2,2,0.7
'PILAR-F12','Mamey','1','Taza','137g',58,13.7,1.4,0.5
'X:1','Mango ataulfo','1','Pieza','95g',40,10.5,0.3,0.2
'X:2','Mango criollo','1','Taza','300g',57,14.6,1.3,0
'X:3','Mango manila','1','Taza','207g',62,16.1,1.2,0
'X:4','Mango petacon','1','Taza','200g',72,12.9,0.6,0.3
'X:5','Mango picado','1','Taza','100g',58,14.9,1.3,0
'X:6','Manzana','1','Pieza','86g',55,14.97,0.3,0.2
'X:7','Manzana al vapor','0.50','Taza','50g',44,11.7,0.2,0.1
'X:8','Manzana amarilla','1','Pieza','130g',65,16.5,0.3,0.3
'X:9','Manzana deshidratada','9','orejones','23g',55,15,0.2,0.1
'X:10','Manzana en almibar o enlatado','1','Pieza','24g',54,15.7,0,0
'X:11','Manzana golden','1','Pieza','130g',65,16.5,0.3,0.3
'X:12','Manzana roja','1','Pieza','139g',63,16.3,0.2,0.4
'X:13','Manzana verde','0.50','Pieza','93g',42,10.8,0.2,0.3
'X:14','Melon','0.33','Pieza','271g',61,14.6,1.5,0.3
'X:15','Melon chino','0.25','Pieza','219g',52,13.1,0.8,0.2
'X:16','Naranja','2','Pieza','242g',72,18,1.4,0.2
'X:17','Naranja cajera','2','Pieza','220g',69,16.4,1.4,1
'X:18','Papaya picada','1','Taza','140g',55,13.7,0.8,0.1
'X:19','Pera','0.50','Pieza','95g',47,12.5,0.3,0.1
'X:20','pera en almibar','0.51','Pieza','76g',44,11.7,0.3,0.1
'X:21','Pera mantequilla','0.52','Pieza','83g',41,10.8,0.3,0.1
'X:22','Banana','0.53','Pieza','80g',48,12.4,0.6,0.2
'X:23','Platano dominico','3','Pieza','105g',54,14,1,0.1
'X:24','sandia picada','1','Taza','160g',48,12.1,1,0.2
'X:25','Toronja','1','Pieza','246g',54,13.7,0.9,0.2
'X:26','Tuna picada','1','Taza','150g',62,14.4,1.1,0.8
'X:27','uva sin semilla o verde o verde sin semilla','1','Taza','92g',55,15,0.6,0.3
'X:28','uva roja','0.75','Taza','90g',57,14.7,0.5,0.3
'X:29','zapote negro','0.50','Taza','150g',52,13.5,0.7,0.1
'X:30','ciruela pasa','1','Taza','100g',240,63.88,2.18,0.38
'X:31','piña','1','Taza','100g',86,13.12,0.54,0.12
'X:32','chabacano','4','Pieza','140g',61,14,1.8,0.5
'X:33','frambueza','1','Taza','123g',64,14.7,1.5,0.8
'X:34','fresa Rebanada','1','Taza','116g',53,12.7,1.1,0.5
'X:35','gajos de mandarina','1','Taza','105g',56,14,0.9,0.3
