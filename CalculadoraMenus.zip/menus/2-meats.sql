'PILAR-C1','Pollo con piña','1','Porción','n/a',491,24.84,26.79,31.53
'PILAR-C2','Picadillo de pollo','1','Porción','n/a',312,33.66,15.83,12.62
'PILAR-C3','Ensalada de pollo','1','Porción','n/a',648,45.2,13.42,45.9
'PILAR-C4','cerdo en verdolaga','1','Porción','n/a',286,6.3,19.82,20.12
'PILAR-C5','Tacos de tinga','1','Porción','n/a',333,30.78,12.26,17.88
'PILAR-C6','Pastel de carne','1','Porción','n/a',414,26.43,18.27,26.19
'PILAR-C7','carne con papas','1','Porción','n/a',606,28.15,26.95,42.8
'PILAR-C8','Carne campreste','1','Porción','n/a',231,10.96,10.18,16.27
'PILAR-C9','Chuletas con col','1','Porción','n/a',411,11.64,19.28,28.01
'PILAR-C10','salpicon de pescado','1','Porción','n/a',314,21.74,29.07,12.27
'PILAR-C11','Pescado en salsa poblana','1','Porción','n/a',234,17.69,25.45,6.69
'PILAR-C12','croquetas de atun','1','Porción','n/a',311,19.42,9.86,21.56
'X:1','carne o pollo o pescado a la plancha','1','Pieza','100g',247.5,0,21,17.5
'X:2','pescado empapelado','1','Pieza','100g',247.5,0,21,17.5
'X:3','pollo a la plancha','1','Pieza','100g',247.5,0,21,17.5
'X:4','ternera al horno en su jugo','2','Rebanadas','100g',247.5,0,21,17.5
'X:5','albondigas de res','2','Pieza','100g',282.5,2,22,20
'Y:1','bistec en salsa morita','1','Pieza','100g',282.5,2,22,20
'Y:2','chicharron en salsa verde','0.50','Taza','100g',282.5,2,22,20
'Y:3','estofado de res','0.50','Taza','100g',282.5,2,22,20
'Y:4','pollo en salsa verde','0.75','Taza','100g',282.5,2,22,20
'Y:5','tinga','0.75','Taza','100g',282.5,2,22,20
'Y:6','albondigas al chipotle','2','Pieza','100g',282.5,2,22,20
'Y:7','costilla de cerdo en salsa de guajillo','2','Pieza','100g',282.5,2,22,20
'Y:8','pescado en salsa de guajillo','2','Pieza','100g',282.5,2,22,20
'Y:9','ropa vieja','1','Taza','100g',282.5,2,22,20
'Y:10','pescado al vino blanco','0.75','Taza','100g',270,0,21,20
'Y:11','res en salsa de vino tinto','0.75','Taza','100g',270,0,21,20
'Y:12','pescado a la veracruzana','0.75','Pieza','100g',247.5,6,20.5,15
'Y:13','Picadillo de pollo','0.75','Pieza','100g',247.5,6,20.5,15
'Y:14','pollo con nopales en salsa verde','0.75','Pieza','100g',247.5,6,20.5,15
'Y:15','pollo a la jardinera','0.75','Pieza','100g',247.5,6,20.5,15
'Y:16','bistec a la mexicana','0.75','Pieza','100g',247.5,6,20.5,15
'Y:17','mole de olla','0.75','Pieza','100g',247.5,6,20.5,15
