'X:1','Barra choco krispis','1','Barra','19g',17,15,1,1.5
'X:2','Barra de fruta con avena fresa','1','Barra','30g',120,17.7,1.6,4.8
'X:3','Barra de granola','0.75','Pieza','21g',101,13.7,2.2,4.2
'X:4','Barra multigrano linaza','1','Barra','20g',99,12,1.9,4.8
'Y:1','Barra zucaritas','1','Barra','20g',90,16,1,2
'Y:2','Barra de granola con cachuate','0.33','Pieza','19g',87,11,1.4,5
'Y:3','Barrita de granola con choco chip','1','Pieza','20g',119,19.6,2.1,4.7
'Y:4','Barrita de granola con pasita y nuez','0.75','Pieza','21g',97,13.5,1.7,4.4
'Y:5','barrita de granola cubierta con chocolate','0.75','Pieza','21g',98,13.4,1.2,5.3
'Y:6','barritas de fresa','0.33','Pieza','21g',97,14.4,1.1,3.9
'Y:7','barrita marinela','20','g','20g',91,13.4,0.7,3.8
'Y:8','Bigote relleno de chocolate','0.33','Pieza','21g',93,11.3,1.5,4.6
'Y:9','bigotes de cajeta','0.33','Pieza','22g',103,9,2.4,5
'Y:10','bigotes de chocolate','0.33','Pieza','22g',103,9,2.4,5
'Y:11','Bigotes miniatura de cajeta','2','Pieza','26g',119,10.5,2.8,5.8
'Y:12','Bimbuñuelos','2','Pieza','30g',120,16,0.9,5.8
'Y:13','bisquet','0.50','Pieza','33g',118,15.8,2,5.4
