'X:1','Agua de melón',2,'Taza','n/a',70,17.5,0,17.5
'X:2','Agua de sandia',2,'Taza','n/a',70,17.5,0,17.5
'X:3','Agua de guayaba',2,'Taza','n/a',70,17.5,0,17.5
'X:4','Agua de piña',2,'Taza','n/a',70,17.5,0,15
'X:5','Agua de sabor',2,'Taza','n/a',60,17.5,0,15
'X:6','Agua de limón',2,'Taza','n/a',60,17.5,0,15
'X:7','Agua de jamica',2,'Taza','n/a',60,17.5,0,12
'X:8','agua de verduras',2,'Taza','n/a',52.5,17.5,1,12
'X:9','agua de pepino',2,'Taza','n/a',52.5,17.5,1,12
'X:10','agua de alfalfa',2,'Taza','n/a',52.5,17.5,1,12
'X:11','Agua',1,'Taza','n/a',0,0,0,0
