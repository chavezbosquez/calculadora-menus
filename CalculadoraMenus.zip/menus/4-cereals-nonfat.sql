'PILAR-C1','Arroz poblano','1','Taza','100g',287,38.93,4.46,12.58
'PILAR-C2','sopa de tortilla','1','Taza','100g',265,24.97,2.64,17.24
'PILAR-C3','arroz mexicano','1','Taza','100g',222,34.3,3.28,7.95
'PILAR-C4','sincronizadas','2','Pieza','100g',338,34.54,10.1,17.56
'PILAR-C5','Macarrones con queso','1','Taza','100g',457,29.6,10.5,32.98
'PILAR-C6','Tallarines con espinaca','1','Taza','100g',406,29.48,9.77,27.62
'PILAR-C7','enchiladas rojas','2','Pieza','100g',594,52.32,17.82,34.82
'PILAR-C8','Cazuela de arroz','1','Taza','100g',377,61.26,9.63,10.33
'PILAR-C9','espagueti con carne','1','Taza','100g',202,30.37,7.8,6.63
'PILAR-C10','piedritas de avena','1','Taza','100g',358,61.87,8.09,9.67
'PILAR-C11','pastel de miel','1','Rebanada','100g',286,43.1,5.49,10.19
'PILAR-C12','galletas de mantequilla','2','Pieza','100g',502,72.18,8.5,19.94
'PILAR-C13','pastel blanco','1','Rebanada','100g',396,67.39,8.13,10.43
'PILAR-C14','betún de miel','1','Rebanada','100g',602,118.45,8.57,10.44
'PILAR-C15','galletas caseras','3','Pieza','100g',392,67.23,8.37,9.92
'PILAR-C16','pastel de zanahoria','1','Rebanada','100g',708,65.09,13.37,43.84
'PILAR-C17','rosca de elote','1','Rebanada','100g',224,24.99,3.98,11.93
'PILAR-C18','pan de maíz','1','Rebanada','100g',552,97.63,12.06,12.5
'PILAR-C19','bizcocho con pasas','1','Rebanada','100g',337,59.95,8.3,7.05
'X:1','pay de queso con guayaba','1','Rebanada','100g',791,85.36,20.6,20.6
'Y:1','espageti con espinaca','1','Taza','100g',61,12.2,2.1,0.3
'Y:2','galleta maria','5','Pieza','n',69,13.8,1.3,1.3
'Y:3','galleta de manzana','1.25','Pieza','19g',65,15.6,0.7,0
'Y:4','amaranto tostado','0.25','Taza','16g',63,11.6,2.2,1.3
'Y:5','papa hervida pelada','0.50','Pieza','63g',54,12.6,1.1,0.1
'Y:6','papa al horno sin cascara','0.50','Pieza','78g',73,16.8,1.6,0.1
'Y:7','pan dulce','0.25','Rebanada','16g',62,9.9,1.5,1.9
'Y:8','pan tostado','1','Rebanada','20g',82,14.8,2.6,1.3
'Y:9','pan integral','1','Rebanada','25g',67,12.6,2.4,1
'Y:10','sopa de pasta','1','Taza','240ml',98.75,16,2.5,2.5
'Y:11','sopa de cereal con verdura','1','Taza','240ml',87.5,13.25,2.5,2.5
'Y:12','sopa de fideos con espinacas','1','Taza','240ml',87.5,13.25,2.5,2.5
'Y:13','sopa de poro y papa','1','Taza','240ml',87.5,13.25,2.5,2.5
'Y:14','sopa de codito con acelgas','1','Taza','240ml',87.5,13.25,2.5,2.5
'Y:15','sopa de letras con zanahoria','1','Taza','240ml',87.5,13.25,2.5,2.5
'Y:16','crema de papa','1','Taza','240ml',150,17.25,6,6.5
'Y:17','crema de elote','1','Taza','240ml',150,17.25,6,6.5
'Y:18','arroz rojo','1','Taza','195g',168.75,31,4.5,2.5
'Y:19','codito al chipotle','1','Taza','195g',168.75,31,4.5,2.5
'Y:20','fideo seco','1','Taza','195g',168.75,31,4.5,2.5
'Y:21','arroz a la jardinera','1','Taza','195g',175,32,5,2.5
'Y:22','arroz a la mexicana','1','Taza','195g',175,32,5,2.5
'Y:23','pasta a la putanesca','1','Taza','195g',175,32,5,2.5
'Y:24','pasta con jitomate','1','Taza','195g',175,32,5,2.5
'Y:25','chilaquiles','1','Taza','195g',175,32,5,2.5
'Y:26','enchiladas rojas','2','Taza','195g',175,32,5,2.5
'Y:27','entomatadas','2','Taza','195g',175,32,5,2.5
'Y:28','Arroz con pollo al horno','1','Taza','210g',282.5,30,11,12.5
'Y:29','codito con atun','1','Taza','210g',282.5,30,11,12.5
'Y:30','macarron con jamon y queso','1','Taza','210g',282.5,30,11,12.5
'Y:31','papas a la francesa','1','Taza','210g',207.5,30,4,7.5
'Y:32','tallarín al chipotle','1','Taza','210g',207.5,30,4,7.5
'Y:33','espagueti con crema','1','Taza','210g',207.5,30,4,7.5
'Y:34','arroz blanco con platano frito','1','Taza','210g',207.5,30,4,7.5
