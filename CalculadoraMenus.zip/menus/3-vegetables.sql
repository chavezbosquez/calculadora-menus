'PILAR-V1','Sopa de elotes con pimientos','1','Taza','100g',251,42.31,6.17,6.27
'PILAR-V2','Chayotes al vapor','1','Taza','100g',85,16.82,2.74,0.76
'PILAR-V3','Sopa juliana','1','Taza','100g',198,24.93,5.86,8.22
'PILAR-V4','Ensalada de brocoli con pimiento','1','Taza','100g',182,11.25,5.75,12.65
'PILAR-V5','Tortilla de pollo con espinacas','1','Taza','100g',323,16.26,14.08,22.46
'PILAR-V6','Sopa de verduras','1','Taza','100g',142,14.77,3.01,7.85
'PILAR-V7','croquetas de zanahorias','1','Taza','100g',333,40.15,8.57,15.31
'PILAR-V8','nopales fritos','1','Taza','100g',152,16.88,2.82,8.12
'PILAR-V9','pimientos rellenos','1','Taza','100g',249,35.69,5.22,9.35
'PILAR-V10','Ensalada de verduras con habas','1','Taza','100g',381,36.26,10.78,21.32
'PILAR-V11','Sopa de aguacate','1','Taza','100g',378,9.79,29.14,24.6
'PILAR-V12','Espinacas con crema','1','Taza','100g',130,7.81,3.93,9.21
'X:1','platanos primavera','1','Taza','100g',343,40.93,1.71,9.81
'X:2','Panque de platano','1','Taza','100g',367,41.34,6.9,19.39
'X:3','Montaña de platano','1','Taza','100g',333,28.29,5.1,23.08
'X:4','Col blanca cruda picada','1.50','Taza','105g',20,4.5,1,0.2
'X:5','Col morada cruda picada','1','Taza','70g',17,4.1,0.8,0.1
'X:6','Coliflor cocida','1.50','Taza','94g',21,3.9,1.7,0.4
'X:7','coliflor verde cocida','0.50','Taza','68g',22,4.2,2.1,0.2
'X:8','Ejotes cocidos picados','0.50','Taza','63g',22,4.9,1.2,0.2
'X:9','Espinaca cocida','0.50','Taza','120g',28,4.4,3.4,0.4
'X:10','lechuga','3','Taza','141g',23,4.5,1.7,0.4
'X:11','Nopal cocido','1','Taza','60g',23,5.3,0.4,0.1
'X:12','Pepinillos crudos','0.33','Taza','80g',23,3.3,1.1,1
'X:13','pepino con cascara rebanado','1.25','Taza','130g',20,4.7,0.8,0.1
'X:14','Zanahoria cruda picada','0.25','Taza','64g',26,4.3,0.6,0.2
