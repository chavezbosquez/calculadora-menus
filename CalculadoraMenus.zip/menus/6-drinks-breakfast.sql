'X:1','Atole de leche en polvo','2','Taza','n/a',729,60.33,10.02,5.7
'X:2','Agua de melón','2','Taza','n/a',70,17.5,0,17.5
'X:3','Agua de sandia','2','Taza','n/a',70,17.5,0,17.5
'X:4','Agua de guayaba','2','Taza','n/a',70,17.5,0,17.5
'X:5','Agua de piña','2','Taza','n/a',70,17.5,0,15
'X:6','Agua de sabor','2','Taza','n/a',60,17.5,0,15
'X:7','Agua de limón','2','Taza','n/a',60,17.5,0,15
'X:8','Agua de jamica','2','Taza','n/a',60,17.5,0,12
'X:9','agua de verduras','2','Taza','n/a',52.5,17.5,1,12
'X:10','agua de pepino','2','Taza','n/a',52.5,17.5,1,12
'X:11','agua de alfalfa','2','Taza','n/a',52.5,17.5,1,12
'X:12','Jugo de papaya con naranja','1','Taza','n/a',120,17.5,0,30
'X:13','jugo de papaya natural','1','Taza','n/a',120,17.5,0,30
'X:14','jugo de naranja natural','1','Taza','n/a',120,17.5,0,30
'X:15','jugo de toronja natural','1','Taza','n/a',120,17.5,0,30
'X:16','jugo de naranja con betabel','2','Taza','n/a',85,17.5,2,19
'X:17','jugo de naranja con zanahoria','1','Taza','n/a',85,17.5,2,19
'X:18','Refrescos y jugos induztrializados','1','Taza','n/a',160,40,0,0
'X:19','café o té con leche','1','Taza','n/a',77.5,13,2.25,2
'X:20','Licuado de platano','1','Taza','n/a',200,24.5,9,8
'X:21','Licuado de fresa','1','Taza','n/a',200,24.5,9,8
'X:22','Licuado de mango','1','Taza','n/a',200,24.5,9,8
'X:23','Licuado de frutas con cereal','1.50','Taza','n/a',280,42,11,8
'X:24','Licuado de platano con avena','1.50','Taza','n/a',280,42,11,8
'X:25','Atole con leche','1','Taza','n/a',185,31,6.5,4
'X:26','Atole de chocolate','1','Taza','n/a',185,31,6.5,4
'X:27','Atole de fresa','1','Taza','n/a',185,31,6.5,4
'X:28','Atole de vainilla','2','Taza','n/a',185,31,6.5,4
