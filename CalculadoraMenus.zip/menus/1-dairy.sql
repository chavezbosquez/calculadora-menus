'PILAR-L3','crema de leche',1,'Taza','n/a',275,15.43,9.51,14.34,15.43
'PILAR-L4','Flan',1,'Pieza','n/a',146,19.77,4.53,6.37,19.77
'PILAR-L5','Salsa de queso',1,'Porción','n/a',407,7.43,32.21,21.8,7.43
'PILAR-L6','Queso en caldillo',1,'Porción','n/a',185,13.2,10.62,9.36,13.2
'PILAR-L7','Chiles rellenos de queso',1,'Porción','n/a',311,19.58,19.46,14.23,19.58
'PILAR-L8','pastel de queso',1,'Rebanada','n/a',431,21.47,17.66,30.52,21.47
'PILAR-L9','Bolitas de queso',1,'Porción','n/a',240,4.1,14.1,18.62,4.1
'PILAR-L10','Crema de queso',1,'Porción','n/a',708,28.37,24.28,44.01,28.37
'PILAR-L11','Pastel de tres leches',1,'Rebanada','n/a',521,70.86,12.71,20.55,70.86
'PILAR-L12','Empanadas de queso en masa de maiz',2,'Pieza','n/a',292,18.34,10.7,19.58,18.34
'PILAR-L13','Natilla de cajeta',1,'Porción','n/a',349,31.48,9.37,20.58,31.48
'PILAR-L14','Dulce de elote',1,'Rebanada','n/a',446,75.96,12.12,10.34,75.96
'PILAR-L15','Enchiladas de requeson',2,'Pieza','n/a',252,38.53,8.29,7.26,38.53
'PILAR-L16','Rollitos de queso',2,'Pieza','n/a',379,22.03,18.85,24.01,22.03
'PILAR-L17','Queso enchilado',1,'Porción','n/a',301,13.19,9.08,23.5,13.19
