'PILAR-H1','Huevo al hoyo',1,'Porción','n/a',188,12.99,8.26,11.43,12.99
'PILAR-H2','Huevo ranchero',1,'Porción','n/a',210,15.96,8.53,12.43,15.96
'PILAR-H3','Huevos perdidos',1,'Porción','n/a',118,7.32,7.64,6.41,7.32
'PILAR-H4','Huevos ahogados',1,'Porción','n/a',202,20.96,9.09,9.14,20.96
'PILAR-H5','Huevos con pimientos',1,'Porción','n/a',89,5.01,5.23,5.31,5.01
'PILAR-H6','Huevos rellenos',1,'Porción','n/a',239,9.89,9.68,17.82,9.89
'PILAR-H7','Huevo con frijoles',1,'Porción','n/a',530,67.23,33.12,14.34,67.23
'PILAR-H8','Huevos sorpresa',1,'Porción','n/a',156,2.74,12.58,10.76,2.74
'PILAR-H9','Huevos motuleños',1,'Porción','n/a',365,42.48,16.72,14.21,42.48
'PILAR-H10','Huevos con ejotes',1,'Porción','n/a',262,9.36,10.71,20.07,9.36
'PILAR-H11','Huevos a la mexicana',1,'Porción','n/a',176,5.24,7.24,13.89,5.24
'PILAR-H12','Tortilla de huevo',1,'Porción','n/a',459,69.43,18.44,11.95,69.43
'Y:1','Huevo con verduras',1,'Pieza','85g',110,2,8,7.5,2
'Y:2','huevo con ejotes',1,'Pieza','85g',110,2,8,7.5,2
'Y:3','huevo con salsa',1,'Pieza','85g',110,2,8,7.5,2
'Y:4','Huevo con embutidos',1,'Pieza','85g',157.5,0,10.5,12.5,0
'Y:5','huevo con chorizo',1,'Pieza','85g',157.5,0,10.5,12.5,0
'Y:6','huevo con jamon',1,'Pieza','85g',157.5,0,10.5,12.5,0
'Y:7','huevo con tocino',1,'Pieza','85g',157.5,0,10.5,12.5,0
'Z:1','huevo con salchicha',1,'Pieza','85g',157.5,0,10.5,12.5,0
'Z:2','huevo con tortilla o papa y salsa',1,'Pieza','85g',218.75,16,9.5,12.5,16
'Z:3','huevo ranchero',1,'Pieza','85g',218.75,16,9.5,12.5,16
'Z:4','huevo revuelto con tortilla',1,'Pieza','85g',218.75,16,9.5,12.5,16
'Z:5','tortilla española',1,'Pieza','85g',218.75,16,9.5,12.5,16
'Z:6','Huevo con leguminosa',1,'Pieza','85g',157.5,10,11,8,10
'Z:7','huevo con salsa de frijol',2,'Pieza','85g',157.5,10,11,8,10
'Z:8','huevo revuelto con frijoles',3,'Pieza','85g',157.5,10,11,8,10
'Z:9','huevo con queso',4,'Pieza','85g',125,0,10.5,9,0
'Z:10','tortilla con salsa,crema y queso',5,'Pieza','85g',270,34,9.5,10,34
'Z:11','chilaquiles',6,'Pieza','85g',270,34,9.5,10,34
'Z:12','enchiladas',7,'Pieza','85g',270,34,9.5,10,34
