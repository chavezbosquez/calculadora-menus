'PILAR-L1','sopa de lentejas',1,'Taza','100g',207,24.84,8.69,8.09
'PILAR-L2','sopa de garbanzo',1,'Taza','100g',175,34.83,5.45,1.53
'PILAR-L3','gorditas de frijol',2,'Pieza','100g',677,91,17.56,27.01
'PILAR-L4','sopa de habas',1,'Taza','100g',318,54.5,18.58,2.83
'PILAR-L5','habas con jitomate',1,'Taza','100g',172,17.61,9.23,7.22
'PILAR-L6','frijoles jarochos',1,'Taza','100g',289,36.42,18.97,7.49
'PILAR-L7','tostadas de frijol',2,'Pieza','100g',642,65.66,18.88,33.7
'PILAR-L8','sopa de alubias',1,'Taza','100g',219,27.57,9.82,8.37
'PILAR-L9','enfrijoladas',2,'Pieza','100g',600,62.7,26.99,26.8
'PILAR-L10','habas con tocino',1,'Taza','100g',221,20.25,12.47,9.78
'PILAR-L11','chicharon con jamon',1,'Taza','100g',284,29.28,18.09,10.44
'PILAR-L12','rosca de frijol',1,'Rebanada','100g',330,48.64,17.52,7.33
'X:1','garbanzo enlatado','0.33','Taza','79g',94,17.9,3.9,0.9
'X:2','alubia enlatada guisada','0.33','Taza','86g',99,18.3,6.3,0.3
'X:3','frijo entero enlatado','0.50','Taza','128g',108,18.6,6.7,0.8
'X:4','frijoles refritos caseros o enlatados','0.33','Taza','75g',95,11.3,4.1,4.1
'X:5','garbanzo cocido','0.50','Taza','82g',135,22.5,7.3,2.1
'X:6','habas cocidas','0.50','Taza','85g',94,16.7,6.5,0.3
'X:7','lenteja cocida','0.50','Taza','99g',115,20,9,0.4
'Y:2','frijoles de la olla','0.50','Taza','110g',187.5,20,8,8.5
'Y:3','frijoles con cilantro','0.50','Taza','110g',187.5,20,8,8.5
'Y:4','frijoles con epazote','0.50','Taza','110g',187.5,20,8,8.5
'Y:5','frijoles con chorizo','0.50','Taza','110g',187.5,20,8,8.5
'Y:6','frijoles con tocino','0.50','Taza','110g',187.5,20,8,8.5
'Y:7','frijoles con queso','0.50','Taza','110g',372.5,32,23.5,16.5
'Y:8','frijoles con puerco','0.50','Taza','110g',372.5,32,23.5,16.5
