'X:1','Tortilla de maiz','3','Pieza','100g',180,39.6,3.6,1.2
'Y:1','Tortilla de maiz','1','Pieza','30g',64,13.6,1.4,0.5
'Y:2','Bolillo','0.33','Pieza','20g',61,12.8,1.9,0
